import { getStore } from '@netlify/blobs'

export default async (req, context) => {
  const store = getStore({ name: 'kylo-rooms', consistency: 'strong' })
  const { id } = context.params || {}
  const method = req.method.toUpperCase()

  if (method === 'OPTIONS') {
    return new Response(null, { status: 204 })
  }

  // POST /api/room — create a new room
  if (!id && method === 'POST') {
    let body = {}
    try { body = await req.json() } catch { /* empty body ok */ }
    const roomId = crypto.randomUUID()
    await store.setJSON(roomId, body)
    return Response.json({ roomId })
  }

  if (!id) {
    return new Response('Room ID required', { status: 400 })
  }

  // GET /api/room/:id — fetch room data
  if (method === 'GET') {
    const data = await store.get(id, { type: 'json' })
    if (!data) return new Response('Not found', { status: 404 })
    return Response.json(data)
  }

  // PUT /api/room/:id — update room data
  if (method === 'PUT') {
    let body
    try { body = await req.json() } catch {
      return new Response('Invalid JSON', { status: 400 })
    }
    await store.setJSON(id, body)
    return Response.json({ ok: true })
  }

  return new Response('Method not allowed', { status: 405 })
}

export const config = {
  path: ['/api/room', '/api/room/:id']
}
